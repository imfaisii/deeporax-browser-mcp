// src/protocol.ts
var DEFAULT_PORT = 17373;
var PROTOCOL_VERSION = "1.0.0";
function isRequest(msg) {
  return typeof msg === "object" && msg !== null && "id" in msg && "method" in msg && !("ok" in msg) && !("type" in msg);
}

// src/page-hooks.ts
var MAX_CONSOLE = 500;
var MAX_NETWORK = 500;
var consoleBuffer = [];
var networkBuffer = [];
function pushConsole(entry) {
  consoleBuffer.push(entry);
  if (consoleBuffer.length > MAX_CONSOLE) {
    consoleBuffer.splice(0, consoleBuffer.length - MAX_CONSOLE);
  }
}
function pushNetwork(entry) {
  networkBuffer.push(entry);
  if (networkBuffer.length > MAX_NETWORK) {
    networkBuffer.splice(0, networkBuffer.length - MAX_NETWORK);
  }
}
function clearConsole() {
  consoleBuffer.length = 0;
}
function clearNetwork() {
  networkBuffer.length = 0;
}
function listConsole(opts) {
  let items = consoleBuffer.slice();
  if (opts.level) {
    const lv = opts.level.toLowerCase();
    items = items.filter((e) => e.level === lv);
  }
  if (opts.pattern) {
    try {
      const re = new RegExp(opts.pattern, "i");
      items = items.filter((e) => re.test(e.text));
    } catch {
      const p = opts.pattern.toLowerCase();
      items = items.filter((e) => e.text.toLowerCase().includes(p));
    }
  }
  const limit = Math.min(opts.limit ?? 100, 500);
  return items.slice(-limit);
}
function listNetwork(opts) {
  let items = networkBuffer.slice();
  if (opts.type) {
    items = items.filter((e) => e.type === opts.type);
  }
  if (opts.pattern) {
    try {
      const re = new RegExp(opts.pattern, "i");
      items = items.filter((e) => re.test(e.url));
    } catch {
      const p = opts.pattern.toLowerCase();
      items = items.filter((e) => e.url.toLowerCase().includes(p));
    }
  }
  const limit = Math.min(opts.limit ?? 100, 500);
  return items.slice(-limit);
}
var MAIN_WORLD_HOOKS = `(() => {
  if (window.__deeporaxHooksInstalled) return;
  window.__deeporaxHooksInstalled = true;
  window.__deeporaxConsole = window.__deeporaxConsole || [];
  window.__deeporaxDialogs = window.__deeporaxDialogs || [];
  window.__deeporaxDialogPolicy = window.__deeporaxDialogPolicy || {};

  const push = (level, args) => {
    try {
      const text = args.map(a => {
        if (typeof a === 'string') return a;
        try { return JSON.stringify(a); } catch { return String(a); }
      }).join(' ');
      const entry = { level, text: text.slice(0, 4000), ts: Date.now(), url: location.href };
      window.__deeporaxConsole.push(entry);
      if (window.__deeporaxConsole.length > 500) window.__deeporaxConsole.shift();
      window.dispatchEvent(new CustomEvent('__deeporax_console', { detail: entry }));
    } catch (_) {}
  };

  for (const level of ['log','info','warn','error','debug']) {
    const orig = console[level] && console[level].bind(console);
    console[level] = (...args) => {
      push(level, args);
      if (orig) return orig(...args);
    };
  }

  window.addEventListener('error', (ev) => {
    push('error', [ev.message + ' at ' + (ev.filename || '') + ':' + (ev.lineno || '')]);
  });
  window.addEventListener('unhandledrejection', (ev) => {
    push('error', ['UnhandledRejection: ' + String(ev.reason)]);
  });

  const policy = () => window.__deeporaxDialogPolicy || {};
  window.alert = (message) => {
    window.__deeporaxDialogs.push({ type: 'alert', message: String(message), ts: Date.now() });
    return undefined;
  };
  window.confirm = (message) => {
    window.__deeporaxDialogs.push({ type: 'confirm', message: String(message), ts: Date.now() });
    const p = policy();
    return p.confirm !== undefined ? Boolean(p.confirm) : true;
  };
  window.prompt = (message, def) => {
    window.__deeporaxDialogs.push({ type: 'prompt', message: String(message), ts: Date.now() });
    const p = policy();
    if (p.prompt === null) return null;
    if (typeof p.prompt === 'string') return p.prompt;
    return def ?? '';
  };
})();`;

// src/background.ts
var PORT = DEFAULT_PORT;
var RECONNECT_MS = 2000;
var ALARM_NAME = "deeporax-browser-mcp-keepalive";
var socket = null;
var reconnectTimer = null;
var lastStatus = "disconnected";
var debuggerAttached = new Set;
var networkByTab = new Map;
var MAX_NET = 500;
function pushNet(tabId, entry) {
  let list = networkByTab.get(tabId);
  if (!list) {
    list = [];
    networkByTab.set(tabId, list);
  }
  list.push(entry);
  if (list.length > MAX_NET)
    list.splice(0, list.length - MAX_NET);
}
function bridgeUrl() {
  return `ws://127.0.0.1:${PORT}`;
}
function setStatus(s) {
  lastStatus = s;
  chrome.action.setBadgeText({ text: s === "connected" ? "ON" : "" });
  chrome.action.setBadgeBackgroundColor({
    color: s === "connected" ? "#16a34a" : "#6b7280"
  });
}
function connect() {
  if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
    return;
  }
  setStatus("connecting");
  try {
    socket = new WebSocket(bridgeUrl());
  } catch {
    scheduleReconnect();
    return;
  }
  socket.addEventListener("open", () => {
    setStatus("connected");
    socket?.send(JSON.stringify({
      type: "hello",
      version: PROTOCOL_VERSION,
      extensionId: chrome.runtime.id
    }));
  });
  socket.addEventListener("message", (ev) => {
    onServerMessage(String(ev.data));
  });
  socket.addEventListener("close", () => {
    setStatus("disconnected");
    socket = null;
    scheduleReconnect();
  });
  socket.addEventListener("error", () => {
    try {
      socket?.close();
    } catch {}
  });
}
function scheduleReconnect() {
  if (reconnectTimer)
    return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connect();
  }, RECONNECT_MS);
}
function respond(res) {
  if (socket?.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(res));
  }
}
async function onServerMessage(raw) {
  let msg;
  try {
    msg = JSON.parse(raw);
  } catch {
    return;
  }
  if (typeof msg === "object" && msg !== null && msg.type === "ping") {
    socket?.send(JSON.stringify({ type: "pong" }));
    return;
  }
  if (!isRequest(msg))
    return;
  try {
    const result = await handleMethod(msg);
    respond({ id: msg.id, ok: true, result });
  } catch (err) {
    respond({
      id: msg.id,
      ok: false,
      error: err instanceof Error ? err.message : String(err)
    });
  }
}
async function resolveTabId(tabId) {
  if (typeof tabId === "number")
    return tabId;
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id)
    throw new Error("No active tab found");
  return tab.id;
}
async function getTab(tabId) {
  const id = await resolveTabId(tabId);
  const tab = await chrome.tabs.get(id);
  return tab;
}
function waitForTabComplete(tabId, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const timer = setInterval(async () => {
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab.status === "complete") {
          clearInterval(timer);
          setTimeout(() => resolve(), 150);
        } else if (Date.now() - start > timeoutMs) {
          clearInterval(timer);
          reject(new Error("Navigation timed out"));
        }
      } catch (err) {
        clearInterval(timer);
        reject(err instanceof Error ? err : new Error(String(err)));
      }
    }, 100);
  });
}
async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "deeporax-browser-mcp-ping" });
    return;
  } catch {}
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  });
}
async function domCall(tabId, method, params = {}) {
  await ensureContentScript(tabId);
  const response = await chrome.tabs.sendMessage(tabId, {
    type: "deeporax-browser-mcp-dom",
    method,
    params
  });
  if (!response?.ok) {
    throw new Error(response?.error || "DOM call failed");
  }
  return response.result;
}
async function domCallFallback(tabId, method, params) {
  const injected = await chrome.scripting.executeScript({
    target: { tabId },
    world: "ISOLATED",
    func: (m, p) => {
      const w = window;
      if (typeof w.__deeporaxHandle === "function") {
        return w.__deeporaxHandle(m, p);
      }
      throw new Error("deeporax-browser-mcp page handler not installed; reload the tab and try again");
    },
    args: [method, params]
  });
  const first = injected[0];
  if (!first)
    throw new Error("executeScript returned no result");
  return first.result;
}
async function safeDom(tabId, method, params = {}) {
  try {
    return await domCall(tabId, method, params);
  } catch {
    return await domCallFallback(tabId, method, params);
  }
}
async function handleMethod(req) {
  const method = req.method;
  const params = req.params ?? {};
  const tabIdParam = params.tabId;
  switch (method) {
    case "active_tab": {
      const tab = await getTab(tabIdParam);
      return {
        id: tab.id,
        url: tab.url,
        title: tab.title,
        status: tab.status,
        windowId: tab.windowId,
        active: tab.active
      };
    }
    case "navigate": {
      const url = String(params.url);
      if (params.newTab) {
        const tab2 = await chrome.tabs.create({ url, active: true });
        if (tab2.id)
          await waitForTabComplete(tab2.id);
        return { tabId: tab2.id, url: tab2.url, title: tab2.title };
      }
      const id = await resolveTabId(tabIdParam);
      await chrome.tabs.update(id, { url });
      await waitForTabComplete(id);
      const tab = await chrome.tabs.get(id);
      return { tabId: id, url: tab.url, title: tab.title };
    }
    case "back": {
      const id = await resolveTabId(tabIdParam);
      await chrome.tabs.goBack(id);
      await waitForTabComplete(id);
      return { ok: true, tabId: id };
    }
    case "forward": {
      const id = await resolveTabId(tabIdParam);
      await chrome.tabs.goForward(id);
      await waitForTabComplete(id);
      return { ok: true, tabId: id };
    }
    case "reload": {
      const id = await resolveTabId(tabIdParam);
      await chrome.tabs.reload(id, { bypassCache: Boolean(params.hard) });
      await waitForTabComplete(id);
      return { ok: true, tabId: id };
    }
    case "tabs": {
      const action = String(params.action);
      if (action === "list") {
        const tabs = await chrome.tabs.query({});
        return tabs.map((t) => ({
          id: t.id,
          url: t.url,
          title: t.title,
          active: t.active,
          windowId: t.windowId
        }));
      }
      if (action === "new") {
        const tab = await chrome.tabs.create({
          url: params.url || "about:blank",
          active: true
        });
        return { id: tab.id, url: tab.url };
      }
      if (action === "close") {
        const id = await resolveTabId(tabIdParam);
        await chrome.tabs.remove(id);
        return { ok: true, closed: id };
      }
      if (action === "select") {
        const id = await resolveTabId(tabIdParam);
        const tab = await chrome.tabs.get(id);
        await chrome.windows.update(tab.windowId, { focused: true });
        await chrome.tabs.update(id, { active: true });
        return { ok: true, tabId: id };
      }
      throw new Error(`Unknown tabs action: ${action}`);
    }
    case "screenshot": {
      const tab = await getTab(tabIdParam);
      if (tab.id == null)
        throw new Error("Tab has no id");
      if (!tab.active) {
        await chrome.tabs.update(tab.id, { active: true });
        await new Promise((r) => setTimeout(r, 100));
      }
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: "png"
      });
      const base64 = dataUrl.replace(/^data:image\/png;base64,/, "");
      return {
        data: base64,
        mimeType: "image/png",
        url: tab.url,
        title: tab.title
      };
    }
    case "snapshot":
    case "click":
    case "type":
    case "press_key":
    case "hover":
    case "select_option":
    case "scroll":
    case "wait":
    case "evaluate":
    case "get_text":
    case "get_html":
    case "fill_form":
    case "find":
    case "click_xy":
    case "drag":
    case "highlight":
    case "file_upload":
    case "get_bounding_box":
    case "is_visible":
    case "dialog_policy":
    case "overlay":
    case "dialogs": {
      const id = await resolveTabId(tabIdParam);
      const tab = await chrome.tabs.get(id);
      if (tab.url?.startsWith("chrome://") || tab.url?.startsWith("chrome-extension://") || tab.url?.startsWith("edge://")) {
        throw new Error(`Cannot access restricted URL: ${tab.url}`);
      }
      await injectMainHooks(id);
      const result = await safeDom(id, method, params);
      if (method === "snapshot") {
        const snap = result;
        return typeof snap === "string" ? snap : snap.text;
      }
      return result;
    }
    case "console": {
      const id = await resolveTabId(tabIdParam);
      await injectMainHooks(id);
      await ensureContentScript(id);
      const response = await chrome.tabs.sendMessage(id, {
        type: "deeporax-browser-mcp-console",
        pattern: params.pattern,
        level: params.level,
        limit: params.limit,
        clear: params.clear
      });
      if (!response?.ok)
        throw new Error(response?.error || "console failed");
      return response.result;
    }
    case "network": {
      const id = await resolveTabId(tabIdParam);
      let requests = networkByTab.get(id)?.slice() ?? [];
      if (params.attach !== false) {
        try {
          await attachDebugger(id);
        } catch {}
      }
      if (params.clear) {
        networkByTab.set(id, []);
        requests = [];
      }
      if (params.pattern) {
        try {
          const re = new RegExp(String(params.pattern), "i");
          requests = requests.filter((r) => re.test(r.url));
        } catch {
          const p = String(params.pattern).toLowerCase();
          requests = requests.filter((r) => r.url.toLowerCase().includes(p));
        }
      }
      const limit = Math.min(Number(params.limit ?? 100), 500);
      try {
        await ensureContentScript(id);
        const response = await chrome.tabs.sendMessage(id, {
          type: "deeporax-browser-mcp-network",
          pattern: params.pattern,
          typeFilter: params.resourceType,
          limit,
          clear: params.clear
        });
        if (response?.ok && response.result?.requests) {
          const extra = response.result.requests;
          const seen = new Set(requests.map((r) => r.id));
          for (const e of extra) {
            if (!seen.has(e.id))
              requests.push(e);
          }
        }
      } catch {}
      requests.sort((a, b) => a.ts - b.ts);
      return { requests: requests.slice(-limit), debuggerAttached: debuggerAttached.has(id) };
    }
    case "resize": {
      const tab = await getTab(tabIdParam);
      const width = Number(params.width);
      const height = Number(params.height);
      if (!Number.isFinite(width) || !Number.isFinite(height)) {
        throw new Error("width and height are required");
      }
      await chrome.windows.update(tab.windowId, {
        width: Math.round(width),
        height: Math.round(height)
      });
      return { ok: true, width, height, windowId: tab.windowId };
    }
    case "batch": {
      const actions = params.actions || [];
      if (!actions.length)
        throw new Error("actions[] required");
      if (actions.length > 25)
        throw new Error("batch limited to 25 actions");
      const results = [];
      for (const action of actions) {
        if (!action?.method)
          throw new Error("each action needs method");
        if (action.method === "batch")
          throw new Error("nested batch not allowed");
        const result = await handleMethod({
          id: req.id + "_sub",
          method: action.method,
          params: { ...action.params, tabId: action.params?.tabId ?? tabIdParam }
        });
        results.push({ method: action.method, result });
      }
      return { results };
    }
    default:
      throw new Error(`Unknown method: ${method}`);
  }
}
async function injectMainHooks(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: (src) => {
        new Function(src)();
      },
      args: [MAIN_WORLD_HOOKS]
    });
  } catch {}
}
async function attachDebugger(tabId) {
  if (debuggerAttached.has(tabId))
    return;
  await chrome.debugger.attach({ tabId }, "1.3");
  debuggerAttached.add(tabId);
  await chrome.debugger.sendCommand({ tabId }, "Network.enable");
}
chrome.debugger.onEvent.addListener((source, method, params) => {
  const tabId = source.tabId;
  if (tabId == null || !params)
    return;
  if (method === "Network.requestWillBeSent") {
    const p = params;
    pushNet(tabId, {
      id: p.requestId,
      method: p.request.method,
      url: p.request.url,
      type: p.type,
      ts: Date.now()
    });
  } else if (method === "Network.responseReceived") {
    const p = params;
    const list = networkByTab.get(tabId);
    const hit = list?.find((r) => r.id === p.requestId);
    if (hit) {
      hit.status = p.response.status;
      hit.type = p.type || hit.type;
    } else {
      pushNet(tabId, {
        id: p.requestId,
        method: "GET",
        url: p.response.url,
        status: p.response.status,
        type: p.type,
        ts: Date.now()
      });
    }
  }
});
chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId != null)
    debuggerAttached.delete(source.tabId);
});
chrome.tabs.onRemoved.addListener((tabId) => {
  networkByTab.delete(tabId);
  if (debuggerAttached.has(tabId)) {
    debuggerAttached.delete(tabId);
    try {
      chrome.debugger.detach({ tabId });
    } catch {}
  }
});
function init() {
  connect();
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: 0.5 });
}
chrome.runtime.onInstalled.addListener(init);
chrome.runtime.onStartup.addListener(init);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    if (!socket || socket.readyState === WebSocket.CLOSED) {
      connect();
    }
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "get-status") {
    sendResponse({
      status: lastStatus,
      port: PORT,
      url: bridgeUrl()
    });
    return true;
  }
  if (msg?.type === "reconnect") {
    try {
      socket?.close();
    } catch {}
    socket = null;
    connect();
    sendResponse({ ok: true });
    return true;
  }
  if (msg?.type === "inject-main-hooks") {
    const tabId = _sender.tab?.id;
    if (tabId != null) {
      injectMainHooks(tabId).then(() => sendResponse({ ok: true }));
      return true;
    }
    sendResponse({ ok: false });
    return false;
  }
  return false;
});
init();
