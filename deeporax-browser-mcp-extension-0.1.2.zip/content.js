// src/agent-overlay.ts
var HOST_ID = "__deeporax_agent_overlay__";
var ACCENT = "#f97316";
var state = null;
var idleTimer = null;
var stopped = false;
var cursorX = -9999;
var cursorY = -9999;
var CSS2 = `
:host { all: initial; }
.wrap {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 2147483647;
  font: 500 13px/1.3 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
}
.frame {
  position: absolute;
  inset: 0;
  border: 3px solid ${ACCENT};
  border-radius: 6px;
  box-shadow:
    inset 0 0 0 1px rgba(249, 115, 22, 0.35),
    inset 0 0 22px rgba(249, 115, 22, 0.25),
    0 0 18px rgba(249, 115, 22, 0.35);
  animation: pulse 1.6s ease-in-out infinite;
  opacity: 0;
  transition: opacity 180ms ease;
}
.frame.on { opacity: 1; }
@keyframes pulse {
  0%, 100% {
    border-color: rgba(249, 115, 22, 0.95);
    box-shadow:
      inset 0 0 0 1px rgba(249, 115, 22, 0.35),
      inset 0 0 22px rgba(249, 115, 22, 0.22),
      0 0 16px rgba(249, 115, 22, 0.30);
  }
  50% {
    border-color: rgba(249, 115, 22, 0.45);
    box-shadow:
      inset 0 0 0 1px rgba(249, 115, 22, 0.18),
      inset 0 0 34px rgba(249, 115, 22, 0.34),
      0 0 26px rgba(249, 115, 22, 0.5);
  }
}
.pill {
  position: absolute;
  top: 14px;
  left: 50%;
  transform: translateX(-50%) translateY(-14px);
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 7px 8px 7px 12px;
  border-radius: 999px;
  background: rgba(17, 17, 19, 0.92);
  color: #fff;
  border: 1px solid rgba(249, 115, 22, 0.55);
  box-shadow: 0 6px 22px rgba(0, 0, 0, 0.35);
  backdrop-filter: blur(8px);
  opacity: 0;
  transition: opacity 180ms ease, transform 180ms ease;
  white-space: nowrap;
  max-width: 78vw;
}
.pill.on { opacity: 1; transform: translateX(-50%) translateY(0); }
.dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: ${ACCENT};
  box-shadow: 0 0 0 0 rgba(249, 115, 22, 0.7);
  animation: blip 1.4s ease-out infinite;
  flex: none;
}
@keyframes blip {
  0% { box-shadow: 0 0 0 0 rgba(249, 115, 22, 0.65); }
  70% { box-shadow: 0 0 0 9px rgba(249, 115, 22, 0); }
  100% { box-shadow: 0 0 0 0 rgba(249, 115, 22, 0); }
}
.label {
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 56vw;
}
.label b { font-weight: 650; }
.label span { opacity: 0.72; font-weight: 400; }
.stop {
  pointer-events: auto;
  cursor: pointer;
  border: 0;
  border-radius: 999px;
  padding: 5px 12px;
  font: 600 12px/1 ui-sans-serif, system-ui, sans-serif;
  color: #fff;
  background: #dc2626;
  flex: none;
}
.stop:hover { background: #ef4444; }
.cursor {
  position: absolute;
  top: 0;
  left: 0;
  width: 22px;
  height: 22px;
  margin: -2px 0 0 -2px;
  opacity: 0;
  transition: opacity 150ms ease;
  will-change: transform;
  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.45));
}
.cursor.on { opacity: 1; }
.ripple {
  position: absolute;
  top: 0;
  left: 0;
  width: 26px;
  height: 26px;
  margin: -13px 0 0 -13px;
  border-radius: 50%;
  border: 2px solid ${ACCENT};
  opacity: 0;
  will-change: transform, opacity;
}
.ripple.go { animation: ring 520ms ease-out 1; }
@keyframes ring {
  0% { opacity: 0.9; transform: scale(0.35); }
  100% { opacity: 0; transform: scale(2.2); }
}
`;
var CURSOR_SVG = `
<svg viewBox="0 0 24 24" width="22" height="22" xmlns="http://www.w3.org/2000/svg">
  <path d="M5 2.5 L5 19.2 L9.1 15.2 L11.7 21.4 L14.6 20.2 L12 14.1 L18 14.1 Z"
        fill="#ffffff" stroke="${ACCENT}" stroke-width="1.6" stroke-linejoin="round"/>
</svg>`;
function ensure() {
  if (state && document.documentElement.contains(state.host))
    return state;
  const host = document.createElement("div");
  host.id = HOST_ID;
  host.setAttribute("aria-hidden", "true");
  host.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:2147483647;";
  const root = host.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = CSS2;
  const wrap = document.createElement("div");
  wrap.className = "wrap";
  const frame = document.createElement("div");
  frame.className = "frame";
  const pill = document.createElement("div");
  pill.className = "pill";
  const dot = document.createElement("div");
  dot.className = "dot";
  const label = document.createElement("div");
  label.className = "label";
  label.innerHTML = "<b>Deeporax agent</b> <span>is controlling this tab</span>";
  const stopBtn = document.createElement("button");
  stopBtn.className = "stop";
  stopBtn.textContent = "Stop";
  stopBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    stopped = true;
    setLabel("stopped by user");
    window.dispatchEvent(new CustomEvent("__deeporax_agent_stop"));
    setTimeout(() => hide(), 900);
  });
  const cursor = document.createElement("div");
  cursor.className = "cursor";
  cursor.innerHTML = CURSOR_SVG;
  const ripple = document.createElement("div");
  ripple.className = "ripple";
  pill.append(dot, label, stopBtn);
  wrap.append(frame, pill, ripple, cursor);
  root.append(style, wrap);
  (document.body || document.documentElement).appendChild(host);
  state = { host, root, frame, pill, label, cursor, ripple, stopBtn };
  return state;
}
function setLabel(action) {
  const s = ensure();
  s.label.innerHTML = `<b>Deeporax agent</b> <span>${escapeHtml(action)}</span>`;
}
function escapeHtml(v) {
  return v.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function showOverlay(action = "is controlling this tab") {
  if (stopped)
    return;
  const s = ensure();
  s.frame.classList.add("on");
  s.pill.classList.add("on");
  setLabel(action);
  if (idleTimer)
    clearTimeout(idleTimer);
  idleTimer = setTimeout(() => hide(), 15000);
}
function hide() {
  if (!state)
    return;
  state.frame.classList.remove("on");
  state.pill.classList.remove("on");
  state.cursor.classList.remove("on");
}
function isStopped() {
  return stopped;
}
function resetStop() {
  stopped = false;
}
function removeOverlay() {
  if (state?.host?.parentNode)
    state.host.parentNode.removeChild(state.host);
  state = null;
}
function prefersReducedMotion() {
  try {
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch {
    return false;
  }
}
function moveCursorTo(x, y, action) {
  const s = ensure();
  if (action)
    showOverlay(action);
  else
    showOverlay();
  s.cursor.classList.add("on");
  const fromX = cursorX < -1000 ? x : cursorX;
  const fromY = cursorY < -1000 ? y : cursorY;
  cursorX = x;
  cursorY = y;
  if (prefersReducedMotion()) {
    s.cursor.style.transform = `translate(${x}px, ${y}px)`;
    return Promise.resolve();
  }
  const dist = Math.hypot(x - fromX, y - fromY);
  const duration = Math.min(620, Math.max(180, dist * 1.15));
  return new Promise((resolve) => {
    const start = performance.now();
    const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
    const step = (now) => {
      const t = Math.min(1, (now - start) / duration);
      const e = easeOutCubic(t);
      const cx = fromX + (x - fromX) * e;
      const cy = fromY + (y - fromY) * e;
      s.cursor.style.transform = `translate(${cx}px, ${cy}px)`;
      if (t < 1) {
        requestAnimationFrame(step);
      } else {
        resolve();
      }
    };
    requestAnimationFrame(step);
  });
}
function clickPulse(x = cursorX, y = cursorY) {
  const s = ensure();
  s.ripple.style.transform = `translate(${x}px, ${y}px)`;
  s.ripple.classList.remove("go");
  s.ripple.offsetWidth;
  s.ripple.classList.add("go");
}
async function cursorToElement(el, action) {
  const r = el.getBoundingClientRect();
  const x = Math.round(r.left + r.width / 2);
  const y = Math.round(r.top + r.height / 2);
  await moveCursorTo(x, y, action);
  clickPulse(x, y);
  return { x, y };
}
function describe(el) {
  const tag = el.tagName.toLowerCase();
  const text = (el.getAttribute("aria-label") || el.placeholder || el.innerText || el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 48);
  return text ? `${tag} "${text}"` : tag;
}

// src/dom-actions.ts
var INTERESTING_SELECTOR = [
  "a[href]",
  "button",
  "input",
  "select",
  "textarea",
  "summary",
  "[role='button']",
  "[role='link']",
  "[role='textbox']",
  "[role='checkbox']",
  "[role='radio']",
  "[role='combobox']",
  "[role='menuitem']",
  "[role='tab']",
  "[role='option']",
  "[role='switch']",
  "[contenteditable='true']",
  "h1",
  "h2",
  "h3",
  "label",
  "img[alt]"
].join(",");
function cssPath(el) {
  if (el.id) {
    const id = CSS.escape(el.id);
    if (document.querySelectorAll(`#${id}`).length === 1)
      return `#${id}`;
  }
  const parts = [];
  let node = el;
  while (node && node.nodeType === 1 && parts.length < 6) {
    let part = node.tagName.toLowerCase();
    if (node.id) {
      part += `#${CSS.escape(node.id)}`;
      parts.unshift(part);
      break;
    }
    const parent = node.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter((c) => c.tagName === node.tagName);
      if (siblings.length > 1) {
        const idx = siblings.indexOf(node) + 1;
        part += `:nth-of-type(${idx})`;
      }
    }
    parts.unshift(part);
    node = parent;
  }
  return parts.join(" > ");
}
function roleOf(el) {
  const explicit = el.getAttribute("role");
  if (explicit)
    return explicit;
  const tag = el.tagName.toLowerCase();
  if (tag === "a")
    return "link";
  if (tag === "button")
    return "button";
  if (tag === "input") {
    const t = el.type || "text";
    if (t === "submit" || t === "button")
      return "button";
    if (t === "checkbox")
      return "checkbox";
    if (t === "radio")
      return "radio";
    return "textbox";
  }
  if (tag === "select")
    return "combobox";
  if (tag === "textarea")
    return "textbox";
  if (tag === "img")
    return "img";
  if (/^h[1-6]$/.test(tag))
    return "heading";
  if (tag === "label")
    return "label";
  if (el.isContentEditable)
    return "textbox";
  return tag;
}
function nameOf(el) {
  const aria = el.getAttribute("aria-label");
  if (aria)
    return aria.trim().slice(0, 120);
  if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
    if (el.placeholder)
      return el.placeholder.trim().slice(0, 120);
    if (el.name)
      return el.name;
    if (el.id) {
      const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (label?.textContent)
        return label.textContent.trim().slice(0, 120);
    }
  }
  if (el instanceof HTMLImageElement && el.alt)
    return el.alt.slice(0, 120);
  const text = (el.textContent || "").replace(/\s+/g, " ").trim();
  return text.slice(0, 120);
}
function isVisible(el) {
  const html = el;
  if (!html.getBoundingClientRect)
    return true;
  const style = window.getComputedStyle(html);
  if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
    return false;
  }
  const r = html.getBoundingClientRect();
  return r.width > 0 && r.height > 0;
}
function buildSnapshot(opts) {
  const interestingOnly = opts.interestingOnly !== false;
  const refs = new Map;
  const refMeta = {};
  let counter = 0;
  const lines = [];
  lines.push(`- page: ${document.title}`);
  lines.push(`  url: ${location.href}`);
  const roots = interestingOnly ? Array.from(document.querySelectorAll(INTERESTING_SELECTOR)).filter(isVisible) : Array.from(document.body?.querySelectorAll("*") || []).filter(isVisible).slice(0, 400);
  const set = new Set(roots);
  const filtered = roots.filter((el) => {
    let p = el.parentElement;
    while (p) {
      if (set.has(p))
        return false;
      p = p.parentElement;
    }
    return true;
  });
  for (const el of filtered.slice(0, 250)) {
    const ref = `e${++counter}`;
    refs.set(ref, el);
    const role = roleOf(el);
    const name = nameOf(el);
    const selector = cssPath(el);
    refMeta[ref] = { selector, role, name };
    let extra = "";
    if (el instanceof HTMLAnchorElement && el.href) {
      extra += ` href="${el.href}"`;
    }
    if (el instanceof HTMLInputElement) {
      extra += ` inputType="${el.type}"`;
      if (el.value && el.type !== "password")
        extra += ` value="${el.value.slice(0, 40)}"`;
      if (el.checked)
        extra += ` checked`;
    }
    if (el instanceof HTMLSelectElement) {
      extra += ` value="${el.value}"`;
    }
    const label = name ? ` "${name.replace(/"/g, "\\\"")}"` : "";
    lines.push(`  - ${role}${label} [${ref}]${extra}`);
  }
  window.__deeporaxRefs = refs;
  return {
    text: lines.join(`
`),
    refs: refMeta,
    url: location.href,
    title: document.title
  };
}
function resolveEl(params) {
  const ref = params.ref;
  const selector = params.selector;
  if (ref) {
    const el = window.__deeporaxRefs?.get(ref);
    if (!el || !document.contains(el)) {
      throw new Error(`Unknown or stale ref "${ref}". Run browser_snapshot again and use a fresh ref.`);
    }
    return el;
  }
  if (selector) {
    const el = document.querySelector(selector);
    if (!el)
      throw new Error(`No element matches selector: ${selector}`);
    return el;
  }
  throw new Error("Provide either ref (from snapshot) or selector");
}
function dispatchKey(el, key) {
  const parts = key.split("+");
  const main = parts[parts.length - 1];
  const mods = {
    ctrlKey: parts.some((p) => /^(control|ctrl)$/i.test(p)),
    altKey: parts.some((p) => /^alt$/i.test(p)),
    shiftKey: parts.some((p) => /^shift$/i.test(p)),
    metaKey: parts.some((p) => /^(meta|cmd|command)$/i.test(p))
  };
  for (const type of ["keydown", "keypress", "keyup"]) {
    el.dispatchEvent(new KeyboardEvent(type, {
      key: main,
      bubbles: true,
      cancelable: true,
      ...mods
    }));
  }
}
function handleDomMethod(method, params) {
  switch (method) {
    case "snapshot":
      return buildSnapshot({
        interestingOnly: params.interestingOnly,
        maxDepth: params.maxDepth
      });
    case "click": {
      const el = resolveEl(params);
      el.scrollIntoView({ block: "center", inline: "center" });
      el.focus?.();
      const dbl = Boolean(params.doubleClick);
      el.dispatchEvent(new MouseEvent(dbl ? "dblclick" : "click", {
        bubbles: true,
        cancelable: true,
        view: window,
        button: params.button === "right" ? 2 : params.button === "middle" ? 1 : 0
      }));
      if (typeof el.click === "function" && !dbl)
        el.click();
      return { ok: true, ref: params.ref, selector: params.selector };
    }
    case "type": {
      const el = resolveEl(params);
      el.scrollIntoView({ block: "center" });
      el.focus?.();
      const text = String(params.text ?? "");
      const append = Boolean(params.append);
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        if (!append) {
          el.value = "";
          el.dispatchEvent(new Event("input", { bubbles: true }));
        }
        if (params.slowly) {
          for (const ch of text) {
            el.value += ch;
            el.dispatchEvent(new Event("input", { bubbles: true }));
            el.dispatchEvent(new KeyboardEvent("keydown", { key: ch, bubbles: true }));
            el.dispatchEvent(new KeyboardEvent("keyup", { key: ch, bubbles: true }));
          }
        } else {
          el.value = append ? el.value + text : text;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
        }
      } else if (el.isContentEditable) {
        if (!append)
          el.textContent = "";
        el.textContent = (append ? el.textContent || "" : "") + text;
        el.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        throw new Error("Element is not typeable");
      }
      if (params.submit) {
        dispatchKey(el, "Enter");
        const form = el.form;
        form?.requestSubmit?.();
      }
      return { ok: true };
    }
    case "press_key": {
      const key = String(params.key ?? "");
      const target = document.activeElement || document.body || document.documentElement;
      dispatchKey(target, key);
      return { ok: true, key };
    }
    case "hover": {
      const el = resolveEl(params);
      el.scrollIntoView({ block: "center" });
      el.dispatchEvent(new MouseEvent("mouseover", { bubbles: true, cancelable: true, view: window }));
      el.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true, cancelable: true, view: window }));
      el.dispatchEvent(new MouseEvent("mousemove", { bubbles: true, cancelable: true, view: window }));
      return { ok: true };
    }
    case "select_option": {
      const el = resolveEl(params);
      if (!(el instanceof HTMLSelectElement)) {
        throw new Error("Element is not a <select>");
      }
      const values = params.values || [];
      for (const opt of Array.from(el.options)) {
        opt.selected = values.includes(opt.value) || values.includes(opt.textContent || "");
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true, value: el.value };
    }
    case "scroll": {
      if (params.ref || params.selector) {
        const el = resolveEl(params);
        el.scrollIntoView({ block: "center", behavior: "instant" });
        return { ok: true, mode: "intoView" };
      }
      const amount = Number(params.amount ?? 600);
      const dir = String(params.direction ?? "down");
      const dx = dir === "left" ? -amount : dir === "right" ? amount : 0;
      const dy = dir === "up" ? -amount : dir === "down" ? amount : 0;
      window.scrollBy(dx, dy);
      return { ok: true, dx, dy, scrollY: window.scrollY };
    }
    case "get_text": {
      if (params.ref || params.selector) {
        const el = resolveEl(params);
        return { text: el.innerText ?? el.textContent ?? "" };
      }
      return { text: document.body?.innerText ?? "" };
    }
    case "get_html": {
      const max = Number(params.maxLength ?? 1e5);
      let html;
      if (params.ref || params.selector) {
        html = resolveEl(params).outerHTML;
      } else {
        html = document.documentElement?.outerHTML ?? "";
      }
      if (html.length > max)
        html = html.slice(0, max) + `
<!-- truncated ${html.length - max} chars -->`;
      return { html };
    }
    case "evaluate": {
      const script = String(params.script ?? "");
      const fn = new Function(`return (${script})`);
      let result;
      try {
        result = fn();
      } catch {
        result = new Function(script)();
      }
      try {
        return { result: JSON.parse(JSON.stringify(result)) };
      } catch {
        return { result: String(result) };
      }
    }
    case "wait": {
      throw new Error("wait must be handled asynchronously");
    }
    case "fill_form": {
      const fields = params.fields || [];
      const results = [];
      for (const field of fields) {
        handleDomMethod("type", { ...field, text: field.value });
        results.push({ ref: field.ref, selector: field.selector, ok: true });
      }
      if (params.submit) {
        const form = document.querySelector("form");
        form?.requestSubmit?.();
      }
      return { ok: true, fields: results };
    }
    case "find": {
      const query = String(params.query ?? "");
      if (!query)
        throw new Error("query is required");
      let re = null;
      if (params.regex) {
        re = new RegExp(query, params.caseSensitive ? "" : "i");
      }
      const matches = [];
      const refs = window.__deeporaxRefs;
      if (refs && refs.size) {
        for (const [ref, el] of refs) {
          if (!document.contains(el))
            continue;
          const role = roleOf(el);
          const name = nameOf(el);
          const text = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
          const hay = `${role} ${name} ${text}`;
          const ok = re ? re.test(hay) : hay.toLowerCase().includes(query.toLowerCase());
          if (ok) {
            matches.push({
              ref,
              role,
              name,
              selector: cssPath(el),
              text: text.slice(0, 160)
            });
          }
        }
      } else {
        const snap = buildSnapshot({ interestingOnly: true });
        for (const [ref, meta] of Object.entries(snap.refs)) {
          const hay = `${meta.role} ${meta.name}`;
          const ok = re ? re.test(hay) : hay.toLowerCase().includes(query.toLowerCase());
          if (ok) {
            matches.push({
              ref,
              role: meta.role,
              name: meta.name,
              selector: meta.selector,
              text: meta.name
            });
          }
        }
      }
      return { query, count: matches.length, matches: matches.slice(0, Number(params.limit ?? 30)) };
    }
    case "click_xy": {
      const x = Number(params.x);
      const y = Number(params.y);
      if (!Number.isFinite(x) || !Number.isFinite(y)) {
        throw new Error("x and y are required numbers (viewport CSS pixels)");
      }
      const el = document.elementFromPoint(x, y);
      const target = el || document.body;
      const common = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: x,
        clientY: y,
        button: params.button === "right" ? 2 : params.button === "middle" ? 1 : 0
      };
      target?.dispatchEvent(new MouseEvent("mousemove", common));
      target?.dispatchEvent(new MouseEvent("mousedown", common));
      target?.dispatchEvent(new MouseEvent("mouseup", common));
      const dbl = Boolean(params.doubleClick);
      target?.dispatchEvent(new MouseEvent(dbl ? "dblclick" : "click", common));
      if (target && typeof target.click === "function" && !dbl && common.button === 0) {
        try {
          target.click();
        } catch {}
      }
      return {
        ok: true,
        x,
        y,
        tag: target?.tagName?.toLowerCase(),
        text: (target?.innerText || "").replace(/\s+/g, " ").trim().slice(0, 80)
      };
    }
    case "drag": {
      const from = resolveEl({
        ref: params.fromRef ?? params.ref,
        selector: params.fromSelector ?? params.selector
      });
      const to = resolveEl({
        ref: params.toRef,
        selector: params.toSelector
      });
      from.scrollIntoView({ block: "center" });
      const a = from.getBoundingClientRect();
      const b = to.getBoundingClientRect();
      const x1 = a.left + a.width / 2;
      const y1 = a.top + a.height / 2;
      const x2 = b.left + b.width / 2;
      const y2 = b.top + b.height / 2;
      const dt = new DataTransfer;
      from.dispatchEvent(new DragEvent("dragstart", {
        bubbles: true,
        cancelable: true,
        dataTransfer: dt,
        clientX: x1,
        clientY: y1
      }));
      to.dispatchEvent(new DragEvent("dragenter", {
        bubbles: true,
        cancelable: true,
        dataTransfer: dt,
        clientX: x2,
        clientY: y2
      }));
      to.dispatchEvent(new DragEvent("dragover", {
        bubbles: true,
        cancelable: true,
        dataTransfer: dt,
        clientX: x2,
        clientY: y2
      }));
      to.dispatchEvent(new DragEvent("drop", {
        bubbles: true,
        cancelable: true,
        dataTransfer: dt,
        clientX: x2,
        clientY: y2
      }));
      from.dispatchEvent(new DragEvent("dragend", {
        bubbles: true,
        cancelable: true,
        dataTransfer: dt,
        clientX: x2,
        clientY: y2
      }));
      return { ok: true, from: cssPath(from), to: cssPath(to) };
    }
    case "highlight": {
      const el = resolveEl(params);
      el.scrollIntoView({ block: "center", inline: "center" });
      const prev = el.getAttribute("data-deeporax-outline");
      if (!prev) {
        el.setAttribute("data-deeporax-outline", el.style.outline || "");
        el.setAttribute("data-deeporax-outline-offset", el.style.outlineOffset || "");
      }
      el.style.outline = String(params.style ?? "3px solid #f97316");
      el.style.outlineOffset = "2px";
      const ms = Number(params.durationMs ?? 2500);
      if (ms > 0) {
        window.setTimeout(() => {
          const o = el.getAttribute("data-deeporax-outline");
          const oo = el.getAttribute("data-deeporax-outline-offset");
          if (o !== null)
            el.style.outline = o;
          if (oo !== null)
            el.style.outlineOffset = oo;
          el.removeAttribute("data-deeporax-outline");
          el.removeAttribute("data-deeporax-outline-offset");
        }, ms);
      }
      const r = el.getBoundingClientRect();
      return {
        ok: true,
        box: { x: r.x, y: r.y, width: r.width, height: r.height }
      };
    }
    case "file_upload": {
      const el = resolveEl(params);
      if (!(el instanceof HTMLInputElement) || el.type !== "file") {
        throw new Error("Target must be an <input type=file>");
      }
      const files = params.files || [];
      if (!files.length)
        throw new Error("files[] required");
      const dt = new DataTransfer;
      for (const f of files) {
        const bin = Uint8Array.from(atob(f.base64), (c) => c.charCodeAt(0));
        const file = new File([bin], f.name, {
          type: f.mimeType || "application/octet-stream"
        });
        dt.items.add(file);
      }
      el.files = dt.files;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return {
        ok: true,
        count: files.length,
        names: files.map((f) => f.name)
      };
    }
    case "get_bounding_box": {
      const el = resolveEl(params);
      const r = el.getBoundingClientRect();
      return {
        x: r.x,
        y: r.y,
        width: r.width,
        height: r.height,
        top: r.top,
        left: r.left,
        bottom: r.bottom,
        right: r.right
      };
    }
    case "is_visible": {
      const el = resolveEl(params);
      return { visible: isVisible(el) };
    }
    case "dialog_policy": {
      const w = window;
      w.__deeporaxDialogPolicy = {
        ...w.__deeporaxDialogPolicy || {},
        ...params.policy
      };
      return {
        ok: true,
        policy: w.__deeporaxDialogPolicy,
        recent: (w.__deeporaxDialogs || []).slice(-10)
      };
    }
    case "dialogs": {
      const w = window;
      const list = w.__deeporaxDialogs || [];
      if (params.clear)
        w.__deeporaxDialogs = [];
      return { dialogs: list };
    }
    default:
      throw new Error(`Unknown DOM method: ${method}`);
  }
}
var POINTER_METHODS = new Set(["click", "hover", "type", "select_option", "fill_form"]);
var ACTION_LABEL = {
  click: "clicking",
  hover: "hovering over",
  type: "typing into",
  select_option: "selecting in",
  fill_form: "filling",
  scroll: "scrolling the page",
  navigate: "navigating",
  snapshot: "reading the page",
  screenshot: "taking a screenshot",
  press_key: "pressing a key",
  drag: "dragging",
  file_upload: "uploading a file"
};
async function handleDomMethodAsync(method, params) {
  const overlayOff = params.overlay === false;
  if (!overlayOff && isStopped()) {
    throw new Error("Agent control was stopped by the user in this tab. Ask them to resume.");
  }
  if (!overlayOff && POINTER_METHODS.has(method)) {
    try {
      if (method === "fill_form") {
        showOverlay("filling a form");
      } else {
        const el = resolveEl(params);
        await cursorToElement(el, `${ACTION_LABEL[method] ?? method} ${describe(el)}`);
      }
    } catch {}
  } else if (!overlayOff && method === "click_xy") {
    const x = Number(params.x);
    const y = Number(params.y);
    if (Number.isFinite(x) && Number.isFinite(y)) {
      await moveCursorTo(x, y, `clicking at ${x}, ${y}`);
      clickPulse(x, y);
    }
  } else if (!overlayOff && ACTION_LABEL[method]) {
    showOverlay(ACTION_LABEL[method]);
  }
  if (method === "overlay") {
    const action = String(params.action ?? "show");
    if (action === "hide") {
      hide();
      return { ok: true, overlay: "hidden" };
    }
    if (action === "remove") {
      removeOverlay();
      return { ok: true, overlay: "removed" };
    }
    if (action === "resume") {
      resetStop();
      showOverlay("resumed control");
      return { ok: true, overlay: "resumed" };
    }
    if (action === "status") {
      return { stopped: isStopped() };
    }
    showOverlay(String(params.label ?? "is controlling this tab"));
    return { ok: true, overlay: "shown" };
  }
  if (method === "wait") {
    const timeoutMs = Math.min(Number(params.timeout ?? 15) * 1000, 60000);
    const start = Date.now();
    if (params.time != null) {
      const ms = Number(params.time) * 1000;
      await new Promise((r) => setTimeout(r, Math.min(ms, timeoutMs)));
      return { ok: true, waited: params.time };
    }
    const deadline = start + timeoutMs;
    while (Date.now() < deadline) {
      if (params.text && document.body?.innerText.includes(String(params.text))) {
        return { ok: true, found: params.text };
      }
      if (params.textGone && !document.body?.innerText.includes(String(params.textGone))) {
        return { ok: true, gone: params.textGone };
      }
      if (params.selector && document.querySelector(String(params.selector))) {
        return { ok: true, selector: params.selector };
      }
      if (!params.text && !params.textGone && !params.selector) {
        throw new Error("wait requires time, text, textGone, or selector");
      }
      await new Promise((r) => setTimeout(r, 200));
    }
    throw new Error(`wait timed out after ${timeoutMs}ms`);
  }
  return handleDomMethod(method, params);
}
function installPageHandler() {
  window.__deeporaxHandle = (method, params) => handleDomMethod(method, params);
}

// src/page-hooks.ts
var MAX_CONSOLE = 500;
var MAX_NETWORK = 500;
var consoleBuffer = [];
var networkBuffer = [];
function pushConsole(entry) {
  consoleBuffer.push(entry);
  if (consoleBuffer.length > MAX_CONSOLE) {
    consoleBuffer.splice(0, consoleBuffer.length - MAX_CONSOLE);
  }
}
function pushNetwork(entry) {
  networkBuffer.push(entry);
  if (networkBuffer.length > MAX_NETWORK) {
    networkBuffer.splice(0, networkBuffer.length - MAX_NETWORK);
  }
}
function clearConsole() {
  consoleBuffer.length = 0;
}
function clearNetwork() {
  networkBuffer.length = 0;
}
function listConsole(opts) {
  let items = consoleBuffer.slice();
  if (opts.level) {
    const lv = opts.level.toLowerCase();
    items = items.filter((e) => e.level === lv);
  }
  if (opts.pattern) {
    try {
      const re = new RegExp(opts.pattern, "i");
      items = items.filter((e) => re.test(e.text));
    } catch {
      const p = opts.pattern.toLowerCase();
      items = items.filter((e) => e.text.toLowerCase().includes(p));
    }
  }
  const limit = Math.min(opts.limit ?? 100, 500);
  return items.slice(-limit);
}
function listNetwork(opts) {
  let items = networkBuffer.slice();
  if (opts.type) {
    items = items.filter((e) => e.type === opts.type);
  }
  if (opts.pattern) {
    try {
      const re = new RegExp(opts.pattern, "i");
      items = items.filter((e) => re.test(e.url));
    } catch {
      const p = opts.pattern.toLowerCase();
      items = items.filter((e) => e.url.toLowerCase().includes(p));
    }
  }
  const limit = Math.min(opts.limit ?? 100, 500);
  return items.slice(-limit);
}
var MAIN_WORLD_HOOKS = `(() => {
  if (window.__deeporaxHooksInstalled) return;
  window.__deeporaxHooksInstalled = true;
  window.__deeporaxConsole = window.__deeporaxConsole || [];
  window.__deeporaxDialogs = window.__deeporaxDialogs || [];
  window.__deeporaxDialogPolicy = window.__deeporaxDialogPolicy || {};

  const push = (level, args) => {
    try {
      const text = args.map(a => {
        if (typeof a === 'string') return a;
        try { return JSON.stringify(a); } catch { return String(a); }
      }).join(' ');
      const entry = { level, text: text.slice(0, 4000), ts: Date.now(), url: location.href };
      window.__deeporaxConsole.push(entry);
      if (window.__deeporaxConsole.length > 500) window.__deeporaxConsole.shift();
      window.dispatchEvent(new CustomEvent('__deeporax_console', { detail: entry }));
    } catch (_) {}
  };

  for (const level of ['log','info','warn','error','debug']) {
    const orig = console[level] && console[level].bind(console);
    console[level] = (...args) => {
      push(level, args);
      if (orig) return orig(...args);
    };
  }

  window.addEventListener('error', (ev) => {
    push('error', [ev.message + ' at ' + (ev.filename || '') + ':' + (ev.lineno || '')]);
  });
  window.addEventListener('unhandledrejection', (ev) => {
    push('error', ['UnhandledRejection: ' + String(ev.reason)]);
  });

  const policy = () => window.__deeporaxDialogPolicy || {};
  window.alert = (message) => {
    window.__deeporaxDialogs.push({ type: 'alert', message: String(message), ts: Date.now() });
    return undefined;
  };
  window.confirm = (message) => {
    window.__deeporaxDialogs.push({ type: 'confirm', message: String(message), ts: Date.now() });
    const p = policy();
    return p.confirm !== undefined ? Boolean(p.confirm) : true;
  };
  window.prompt = (message, def) => {
    window.__deeporaxDialogs.push({ type: 'prompt', message: String(message), ts: Date.now() });
    const p = policy();
    if (p.prompt === null) return null;
    if (typeof p.prompt === 'string') return p.prompt;
    return def ?? '';
  };
})();`;

// src/content.ts
installPageHandler();
window.addEventListener("__deeporax_console", (ev) => {
  const detail = ev.detail;
  if (detail)
    pushConsole(detail);
});
try {
  const po = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
      if (entry.entryType !== "resource")
        continue;
      const re = entry;
      pushNetwork({
        id: `perf_${Math.round(re.startTime)}_${re.name.slice(-24)}`,
        method: "GET",
        url: re.name,
        status: undefined,
        type: re.initiatorType,
        ts: Date.now()
      });
    }
  });
  po.observe({ type: "resource", buffered: true });
} catch {}
var origFetch = window.fetch.bind(window);
window.fetch = async (input, init) => {
  const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
  const method = (init?.method || (input instanceof Request ? input.method : "GET")).toUpperCase();
  const id = `fetch_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  try {
    const res = await origFetch(input, init);
    pushNetwork({
      id,
      method,
      url,
      status: res.status,
      type: "fetch",
      ts: Date.now()
    });
    return res;
  } catch (err) {
    pushNetwork({
      id,
      method,
      url,
      status: 0,
      type: "fetch",
      ts: Date.now()
    });
    throw err;
  }
};
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message)
    return false;
  if (message.type === "deeporax-browser-mcp-ping") {
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === "deeporax-browser-mcp-console") {
    if (message.clear)
      clearConsole();
    try {
      const mainBuf = window.__deeporaxConsole;
      if (Array.isArray(mainBuf)) {
        for (const e of mainBuf)
          pushConsole(e);
        if (message.clear) {
          window.__deeporaxConsole = [];
        }
      }
    } catch {}
    sendResponse({
      ok: true,
      result: {
        messages: listConsole({
          pattern: message.pattern,
          level: message.level,
          limit: message.limit
        })
      }
    });
    return false;
  }
  if (message.type === "deeporax-browser-mcp-network") {
    if (message.clear)
      clearNetwork();
    sendResponse({
      ok: true,
      result: {
        requests: listNetwork({
          pattern: message.pattern,
          type: message.typeFilter,
          limit: message.limit
        })
      }
    });
    return false;
  }
  if (message.type !== "deeporax-browser-mcp-dom")
    return false;
  const { method, params } = message;
  handleDomMethodAsync(method, params ?? {}).then((result) => sendResponse({ ok: true, result })).catch((err) => sendResponse({
    ok: false,
    error: err instanceof Error ? err.message : String(err)
  }));
  return true;
});
chrome.runtime.sendMessage({ type: "inject-main-hooks" }).catch(() => {});
console.debug("[deeporax] content script ready", location.href);
